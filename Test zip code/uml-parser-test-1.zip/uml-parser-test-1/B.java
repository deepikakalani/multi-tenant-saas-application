 

public class B {
 
	private A a;
	 
}
 
